require 'sinatra'
require 'rest-client'
require 'json' 			
require 'octokit'




CLIENT_ID = '
CLIENT_SECRET = '<YOUR_CLIENT_SECRET>'


